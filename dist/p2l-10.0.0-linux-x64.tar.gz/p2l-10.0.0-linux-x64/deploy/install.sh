#!/usr/bin/env bash
# install.sh — Install P2L service + Web Client binaries on Linux or macOS.
# No Python runtime required on the target machine.
#
# Linux  : sudo ./deploy/install.sh
# macOS  : ./deploy/install.sh

set -euo pipefail
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
OS="$(uname -s)"
INSTALL_DIR="/opt/p2l"
P2L_USER="p2l"

# ── Helper: install systemd units ────────────────────────────────────────────
_install_systemd() {
    info "Installing systemd units ..."
    cat > /etc/systemd/system/p2l.service <<UNIT
[Unit]
Description=Pick2Light (P2L) Warehouse Control Daemon
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${P2L_USER}
Group=${P2L_USER}
WorkingDirectory=${INSTALL_DIR}
ExecStart=${INSTALL_DIR}/p2l run ${INSTALL_DIR}/tasks.csv
Environment=LD_LIBRARY_PATH=${INSTALL_DIR}
KillSignal=SIGTERM
TimeoutStopSec=20s
Restart=always
RestartSec=5s
StandardOutput=journal
StandardError=journal
SyslogIdentifier=p2l
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=${INSTALL_DIR}/logs ${INSTALL_DIR}

[Install]
WantedBy=multi-user.target
UNIT

    cat > /etc/systemd/system/p2l-client.service <<UNIT
[Unit]
Description=Pick2Light Web Dashboard (P2L Client)
After=network-online.target p2l.service
Wants=network-online.target

[Service]
Type=simple
User=${P2L_USER}
Group=${P2L_USER}
WorkingDirectory=${INSTALL_DIR}
ExecStart=${INSTALL_DIR}/p2l-client
Environment=P2L_CLIENT_HOST=0.0.0.0
Environment=P2L_CLIENT_PORT=8765
KillSignal=SIGTERM
TimeoutStopSec=15s
Restart=always
RestartSec=5s
StandardOutput=journal
StandardError=journal
SyslogIdentifier=p2l-client
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=${INSTALL_DIR}

[Install]
WantedBy=multi-user.target
UNIT

    systemctl daemon-reload
    systemctl enable p2l p2l-client
    ok "systemd units enabled"

    read -r -p "Start services now? [y/N] " START
    if [[ "${START,,}" == "y" ]]; then
        systemctl start p2l; sleep 1
        systemctl start p2l-client; sleep 1
        systemctl status p2l --no-pager
        systemctl status p2l-client --no-pager
    fi
}

# ── Helper: install launchd agents ────────────────────────────────────────────
_install_launchd() {
    info "Installing launchd agents (macOS) ..."
    local LOG_DIR="$HOME/Library/Logs/P2L"
    local LAUNCH_DIR="$HOME/Library/LaunchAgents"
    mkdir -p "$LOG_DIR" "$LAUNCH_DIR"

    cat > "$LAUNCH_DIR/com.p2l.service.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
    <key>Label</key>             <string>com.p2l.service</string>
    <key>ProgramArguments</key>  <array><string>${INSTALL_DIR}/p2l</string><string>run</string><string>${INSTALL_DIR}/tasks.csv</string></array>
    <key>WorkingDirectory</key>  <string>${INSTALL_DIR}</string>
    <key>EnvironmentVariables</key><dict><key>DYLD_LIBRARY_PATH</key><string>${INSTALL_DIR}</string></dict>
    <key>RunAtLoad</key>         <true/>
    <key>KeepAlive</key>         <dict><key>SuccessfulExit</key><false/></dict>
    <key>ThrottleInterval</key>  <integer>5</integer>
    <key>StandardOutPath</key>   <string>${LOG_DIR}/p2l.log</string>
    <key>StandardErrorPath</key> <string>${LOG_DIR}/p2l.log</string>
</dict></plist>
PLIST

    cat > "$LAUNCH_DIR/com.p2l.client.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
    <key>Label</key>             <string>com.p2l.client</string>
    <key>ProgramArguments</key>  <array><string>${INSTALL_DIR}/p2l-client</string></array>
    <key>WorkingDirectory</key>  <string>${INSTALL_DIR}</string>
    <key>EnvironmentVariables</key><dict>
        <key>P2L_CLIENT_HOST</key><string>0.0.0.0</string>
        <key>P2L_CLIENT_PORT</key><string>8765</string>
    </dict>
    <key>RunAtLoad</key>         <true/>
    <key>KeepAlive</key>         <dict><key>SuccessfulExit</key><false/></dict>
    <key>ThrottleInterval</key>  <integer>5</integer>
    <key>StandardOutPath</key>   <string>${LOG_DIR}/p2l-client.log</string>
    <key>StandardErrorPath</key> <string>${LOG_DIR}/p2l-client.log</string>
</dict></plist>
PLIST

    launchctl unload "$LAUNCH_DIR/com.p2l.service.plist" 2>/dev/null || true
    launchctl unload "$LAUNCH_DIR/com.p2l.client.plist"  2>/dev/null || true
    launchctl load   "$LAUNCH_DIR/com.p2l.service.plist"
    launchctl load   "$LAUNCH_DIR/com.p2l.client.plist"
    ok "launchd agents installed and loaded"
}

# ── Pre-flight ────────────────────────────────────────────────────────────────
[[ -f "$PKG_ROOT/bin/p2l" ]]        || error "Binary not found: $PKG_ROOT/bin/p2l"
[[ -f "$PKG_ROOT/bin/p2l-client" ]] || error "Client binary not found: $PKG_ROOT/bin/p2l-client"

if [[ "$OS" == "Linux" ]]; then
    [[ $EUID -eq 0 ]] || error "Run as root: sudo ./deploy/install.sh"
fi

info "Installing to: $INSTALL_DIR"

# ── Create system user (Linux only) ──────────────────────────────────────────
if [[ "$OS" == "Linux" ]]; then
    if ! id -u "$P2L_USER" &>/dev/null; then
        useradd --system --no-create-home --shell /usr/sbin/nologin "$P2L_USER"
        info "Created system user: $P2L_USER"
    fi
fi

# ── Install binaries + SQLite native lib ─────────────────────────────────────
info "Installing binaries ..."
mkdir -p "$INSTALL_DIR/logs"
install -m 0755 "$PKG_ROOT/bin/p2l"        "$INSTALL_DIR/p2l"
install -m 0755 "$PKG_ROOT/bin/p2l-client" "$INSTALL_DIR/p2l-client"

for sqlite_lib in "$PKG_ROOT/bin/"libe_sqlite3.* "$PKG_ROOT/bin/"e_sqlite3.*; do
    [[ -f "$sqlite_lib" ]] && install -m 0644 "$sqlite_lib" "$INSTALL_DIR/" && ok "Installed $(basename "$sqlite_lib")"
done

[[ -f "$PKG_ROOT/config/appsettings.json" ]] && \
    install -m 0640 "$PKG_ROOT/config/appsettings.json" "$INSTALL_DIR/appsettings.json"
ok "Binaries installed"

# ── Fix permissions (Linux) ───────────────────────────────────────────────────
if [[ "$OS" == "Linux" ]]; then
    chown -R "$P2L_USER:$P2L_USER" "$INSTALL_DIR"
    chmod 755 "$INSTALL_DIR"
fi

# ── Install services ──────────────────────────────────────────────────────────
if [[ "$OS" == "Linux" ]]; then
    _install_systemd
elif [[ "$OS" == "Darwin" ]]; then
    INSTALL_DIR="$HOME/Library/Application Support/P2L"
    mkdir -p "$INSTALL_DIR/logs"
    install -m 0755 "$PKG_ROOT/bin/p2l"        "$INSTALL_DIR/p2l"
    install -m 0755 "$PKG_ROOT/bin/p2l-client" "$INSTALL_DIR/p2l-client"
    for sqlite_lib in "$PKG_ROOT/bin/"libe_sqlite3.* "$PKG_ROOT/bin/"e_sqlite3.*; do
        [[ -f "$sqlite_lib" ]] && install -m 0644 "$sqlite_lib" "$INSTALL_DIR/"
    done
    [[ -f "$PKG_ROOT/config/appsettings.json" ]] && \
        install -m 0640 "$PKG_ROOT/config/appsettings.json" "$INSTALL_DIR/appsettings.json"
    _install_launchd
fi

echo ""
ok "=== Installation complete ==="
if [[ "$OS" == "Linux" ]]; then
    echo "  Start bridge  : sudo systemctl start p2l"
    echo "  Start client  : sudo systemctl start p2l-client"
    echo "  Dashboard     : http://localhost:8765"
    echo "  Logs bridge   : journalctl -u p2l -f"
    echo "  Logs client   : journalctl -u p2l-client -f"
elif [[ "$OS" == "Darwin" ]]; then
    echo "  Dashboard     : http://localhost:8765"
    echo "  Logs bridge   : tail -f ~/Library/Logs/P2L/p2l.log"
    echo "  Logs client   : tail -f ~/Library/Logs/P2L/p2l-client.log"
    echo "  Stop bridge   : launchctl unload ~/Library/LaunchAgents/com.p2l.service.plist"
    echo "  Stop client   : launchctl unload ~/Library/LaunchAgents/com.p2l.client.plist"
fi
