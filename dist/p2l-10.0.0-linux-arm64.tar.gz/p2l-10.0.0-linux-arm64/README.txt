Pick2Light (P2L) — p2l-10.0.0-linux-arm64
=====================================

CONTENTS
  bin/p2l                 P2L .NET bridge service (Aioi gateway ↔ MQTT)
  bin/p2l-client          P2L web dashboard — standalone binary (no Python required)
  config/appsettings.json P2L bridge configuration
  deploy/                 Installation scripts & systemd units

REQUIREMENTS
  No Python runtime required — p2l-client is self-contained.
  MQTT broker   (e.g. EMQX)

INSTALL — Linux / macOS
  sudo ./deploy/install.sh        # Linux (systemd)
  ./deploy/install.sh             # macOS (launchd)

INSTALL — Windows
  # Run PowerShell as Administrator:
  .\deploy\install.ps1

CONFIGURATION
  Edit config/appsettings.json before installing, or set environment variables:
    P2L_GATEWAY__HOST=192.168.1.254
    P2L_GATEWAY__PORT=5003
    P2L_MQTT__HOST=your-broker
    P2L_MQTT__USERNAME=user
    P2L_MQTT__PASSWORD=pass

  p2l_config.json is created next to p2l-client on first run.

DASHBOARD
  http://localhost:8765  (after services are running)

LOGS
  Linux   : journalctl -u p2l -f  |  journalctl -u p2l-client -f
  macOS   : tail -f /var/log/p2l.log  |  tail -f /var/log/p2l-client.log
  Windows : C:\ProgramData\P2L\logs\

MORE
  See https://github.com/your-org/p2l for documentation.
